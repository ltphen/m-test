import { AppError } from './AppError';

export class ServerInternalError extends AppError {

}