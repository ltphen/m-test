export class AppError {
	constructor(public error?:any){};
}