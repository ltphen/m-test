import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

/* 
* @name AppComponent
* @role have to verify if you are login / if you have an account and send you to the appropriate room
*/
export class AppComponent {

  title = 'MendoLearn';

  constructor(){
  }


}
